package modelo.deportes;

public class Voleibol extends DeporteColectivo{

	public Voleibol() {
		super("Voleibol",6);
		// TODO Auto-generated constructor stub
	}
	@Override
    public boolean permiteEmpate() {
        return false;
    }
    @Override
    public int puntosLiga(int propio, int rival) {
        if (propio == rival) {
            throw new IllegalArgumentException("El voleibol no permite empates.");
        }
        if (propio > rival) return 2; // Supuesto del club para el sistema de puntos
        return 0;
    }
    @Override
    public boolean aceptaStats(StatsPartido s) {
        return s instanceof VoleibolStats;
    }

}
