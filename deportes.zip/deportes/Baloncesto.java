package modelo.deportes;

public class Baloncesto extends DeporteColectivo{

	public Baloncesto() {
		super("Baloncesto", 5);
		// TODO Auto-generated constructor stub
	}

	@Override
    public boolean permiteEmpate() {
        return false;
    }

    @Override
    public int puntosLiga(int propio, int rival) {
        if (propio ==rival) {
            throw new IllegalArgumentException("El baloncesto no permite empates.");
        }
        if (propio > rival) return 2;
        return 0;
    }

    @Override
    public boolean aceptaStats(StatsPartido s) {
        return s instanceof BaloncestoStats;
    }
	}
