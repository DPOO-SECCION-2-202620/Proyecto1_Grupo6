package modelo.deportes;
import modelo.usuarios.Jugador;
public abstract class StatsPartido {
    protected int minJugados;
    protected Jugador jugador;
    public StatsPartido(Jugador jugador, int minJugados) {  
        if (jugador == null) {  
            throw new IllegalArgumentException("El jugador no puede ser nulo.");  
        }  

        if (minJugados < 0) {  
            throw new IllegalArgumentException("min no negativos");  
        }  
        this.jugador = jugador;  
        this.minJugados = minJugados;  
    }

    public int getMinJugados() {  
        return minJugados;  
    }

    public Jugador getJugador() {  
        return jugador;  
    }
}