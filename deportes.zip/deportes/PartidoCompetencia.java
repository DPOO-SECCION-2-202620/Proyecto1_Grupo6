package modelo.deportes;
import java.time.LocalDate;
import modelo.deportes.DeporteColectivo;
import modelo.deportes.Equipo;
import modelo.deportes.Partido;
import modelo.usuarios.Jugador;
public class PartidoCompetencia extends Partido {
    private Equipo equipoCDS;
    private String institucionRival;
    private String escenario;
    private boolean resultadoRegistrado;
    public PartidoCompetencia(String idPartido, LocalDate fecha, Equipo equipoCDS,
                              String institucionRival, String escenario) {
        super(idPartido, fecha);
        if (idPartido == null || idPartido.isBlank() || fecha == null || equipoCDS == null
                || institucionRival == null || institucionRival.isBlank()
                || escenario == null || escenario.isBlank()) {
            throw new IllegalArgumentException("Faltan datos del partido");
        }
        this.equipoCDS = equipoCDS;
        this.institucionRival = institucionRival;
        this.escenario = escenario;
        this.resultadoRegistrado = false;
    }
    public void registrarResultado(int golesOPuntosCDS, int golesOPuntosRival) {
        if (resultadoRegistrado) {
            throw new IllegalStateException("Ya se registró el resultado");
        }
        registrarMarcador(golesOPuntosCDS, golesOPuntosRival);
        resultadoRegistrado = true;
    }

    @Override
    public DeporteColectivo getDeporte() {
        return equipoCDS.getDeporte();
    }

    @Override
    public boolean jugadorPerteneceAlPartido(Jugador jugador) {
        return equipoCDS.getNominaJugadores().contains(jugador);
    }

    public Equipo getLocal() { return equipoCDS; }
    public Equipo getEquipo() { return equipoCDS; }

    public String getIdPartido() { return idPartido; }
    public String getInstitucionRival() { return institucionRival; }
    public String getEscenario() { return escenario; }
    public int getMarcadorCDS() { return marcadorLocal; }
    public int getMarcadorRival() { return marcadorVisitante; }
    public boolean isResultadoRegistrado() { return resultadoRegistrado; }
}