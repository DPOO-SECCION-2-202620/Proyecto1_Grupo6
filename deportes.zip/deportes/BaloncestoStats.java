package modelo.deportes;
import modelo.usuarios.Jugador;
public class BaloncestoStats extends StatsPartido{
	private int puntos;
	private int rebotes;
		// TODO Auto-generated constructor stub
	public BaloncestoStats(Jugador jugador, int minJugados, int puntos, int rebotes) {
	super(jugador, minJugados);
	        if (puntos < 0 || rebotes < 0) {
	            throw new IllegalArgumentException("No pueden ser negativos los puntos ");
	        }
	        this.puntos = puntos;
	        this.rebotes = rebotes;
	    }
	public int getPuntos() {
		return puntos;
	}
	public int getRebotes() {
		return rebotes;
	}
	
}
