package modelo.deportes;

import java.time.LocalDate;
import modelo.usuarios.Jugador;

public class PartidoInterno extends Partido {
   private Equipo local;
    private Equipo visitante;

    public PartidoInterno(String idPartido, LocalDate fecha, Equipo local, Equipo visitante) {
       super(idPartido, fecha);
       if (local== null ||visitante ==null) {
            throw new IllegalArgumentException("nulos");
       }
      if (local.equals(visitante)) {
            throw new IllegalArgumentException("no puede jugar contra sí mismo.");
       }
        if (!local.getDeporte().equals(visitante.getDeporte())) {
           throw new IllegalArgumentException("mismo deport");
        }
       if (!local.getCategoria().equals(visitante.getCategoria())) {
            throw new IllegalArgumentException("misma categoría");
        }
      if (!local.cumpleMinimoJugadores() || !visitante.cumpleMinimoJugadores()) {
           throw new IllegalStateException("mínimo de jugadores");
        }
        this.local= local;
       this.visitante =visitante;
    }
    @Override
    public DeporteColectivo getDeporte() {
        return local.getDeporte();
    }    @Override
    public boolean jugadorPerteneceAlPartido(Jugador jugador) {
        if (jugador== null) return false;
        return local.getNominaJugadores().contains(jugador) ||visitante.getNominaJugadores().contains(jugador);
   }

    public Equipo getLocal() {
        return local;
   }
    public Equipo getVisitante() {
       return visitante;
    }
}