package modelo.deportes;

public abstract class Deporte {
	protected String nombre;

	public Deporte(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}
	public abstract boolean permiteEmpate();
	
	@Override
    public boolean equals(Object o) {
        if (!(o instanceof Deporte)) return false;
        return nombre.equals(((Deporte) o).nombre);
    }

    @Override
    public int hashCode() {
        return nombre.hashCode();
    }
 }
