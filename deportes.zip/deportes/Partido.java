package modelo.deportes;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import modelo.usuarios.Jugador;
public abstract class Partido {
    protected String idPartido;
    protected LocalDate fecha;
    protected int marcadorLocal;
    protected int marcadorVisitante;
    protected List<StatsPartido> statsPartidos;
    public Partido(String idPartido, LocalDate fecha) {
        if (idPartido == null || idPartido.trim().isEmpty() || fecha == null) {
            throw new IllegalArgumentException("Datos del partido inválidos.");
        }
        this.idPartido = idPartido;
        this.fecha = fecha;
        this.marcadorLocal = 0;
        this.marcadorVisitante = 0;
        this.statsPartidos = new ArrayList<>();
    }
    public abstract DeporteColectivo getDeporte();
    public abstract boolean jugadorPerteneceAlPartido(Jugador jugador);

    public void registrarMarcador(int local, int visitante) {
        if (local < 0 || visitante < 0) {
            throw new IllegalArgumentException("Los marcadores no pueden ser negativos.");
        }
        if (local == visitante && !getDeporte().permiteEmpate()) {
            throw new IllegalArgumentException("El deporte no permite empates.");
        }
        this.marcadorLocal = local;
        this.marcadorVisitante = visitante;
    }
    public String getIdPartido() { return idPartido; }
    public LocalDate getFecha() { return fecha; }
    public int getMarcadorLocal() { return marcadorLocal; }
    public int getMarcadorVisitante() { return marcadorVisitante; }
}