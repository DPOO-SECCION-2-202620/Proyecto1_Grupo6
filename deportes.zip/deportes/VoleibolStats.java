package modelo.deportes;
import modelo.usuarios.Jugador;
public class VoleibolStats extends StatsPartido{
	private int aces;
	private int bloqueos;
	public VoleibolStats(Jugador jugador, int minJugados, int aces, int bloqueos) {
        super(jugador,minJugados);
        if (aces<0||bloqueos<0) {
            throw new IllegalArgumentException("No pueden ser negativas las stats de volley");
        }
        this.aces = aces;
        this.bloqueos = bloqueos;
    }
	public int getAces() {
		return aces;
	}
	public int getBloqueos() {
		return bloqueos;
	}
	
}
