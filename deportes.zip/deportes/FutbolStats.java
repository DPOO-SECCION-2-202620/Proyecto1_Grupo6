package modelo.deportes;
import modelo.usuarios.Jugador;
public class FutbolStats extends StatsPartido{
	private int goles;
	private int asistencias;
	private int amarillas;
	private int rojas;
	public FutbolStats(Jugador jugador, int minJugados, int goles, int asistencias, int amarillas, int rojas) {
        super(jugador, minJugados);
        if (goles < 0||asistencias<0||amarillas<0||rojas <0) {
            throw new IllegalArgumentException("Las estadísticas de fútbol no pueden ser negativas.");
        }
        this.goles = goles;
        this.asistencias = asistencias;
        this.amarillas = amarillas;
        this.rojas = rojas;
    }
	
	public boolean generaSuspension() {
        return amarillas >= 2 || rojas >= 1;
    }

	public int getGoles() {
		return goles;
	}

	public int getAsistencias() {
		return asistencias;
	}

	public int getAmarillas() {
		return amarillas;
	}

	public int getRojas() {
		return rojas;
	}

    
}
	