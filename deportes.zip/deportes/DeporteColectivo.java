package modelo.deportes;

public abstract class DeporteColectivo extends Deporte{
	protected int minJugadores ;

	public DeporteColectivo(String nombre, int minJugadores) {
		super(nombre);
		this.minJugadores = minJugadores;
	}

	public int getMinJugadores() {
		return minJugadores;
	}
	
	public abstract boolean permiteEmpate();
    public abstract int puntosLiga(int propio, int rival);
    public abstract boolean aceptaStats(StatsPartido s);
}
