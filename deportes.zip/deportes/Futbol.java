package modelo.deportes;

public class Futbol extends DeporteColectivo{

	public Futbol() {
		super("Futbol", 7);
		// TODO Auto-generated constructor stub
	}
	@Override
    public boolean permiteEmpate() {
        return true;
    }
    @Override
    public int puntosLiga(int propio, int rival) {
        if (propio>rival) return 3;
        if (propio==rival) return 1;
        return 0;
    }
    @Override
    public boolean aceptaStats(StatsPartido s) {
        return s instanceof FutbolStats;
    }
}	
