package modelo.deportes;
import java.util.ArrayList;
import java.util.List;
import modelo.comun.Categoria;
import modelo.usuarios.Jugador;
public class Equipo {
    private String nombre;
    private int cupoMaximo;
    private Categoria categoria;
    private String estado;
    private DeporteColectivo deporte;
    private List<Jugador> nominaJugadores;
    public Equipo(String nombre, int cupoMaximo, Categoria categoria, DeporteColectivo deporte) {
        if (nombre == null || cupoMaximo <= 0 || categoria == null || deporte == null) {
            throw new IllegalArgumentException("Parámetros de equipo inválidos.");
        }
       this.nombre = nombre;
        this.cupoMaximo =cupoMaximo;
       this.categoria = categoria;
       this.estado= "Activo";
        this.deporte = deporte;
        this.nominaJugadores =new ArrayList<>();
   }
    public boolean agregarJugador(Jugador jugador) {
       if (jugador == null) {
            throw new IllegalArgumentException("No se puede agregar");
        }
       if (nominaJugadores.size() >= cupoMaximo) {
           throw new IllegalStateException("Se ha alcanzado el cupo máximo del equipo");
        }
       if (nominaJugadores.contains(jugador)) {
           throw new IllegalArgumentException("Ya se encuentra registrad");
        }
       nominaJugadores.add(jugador);
       return true;
    }
    public boolean cumpleMinimoJugadores() {
       return nominaJugadores.size() >= deporte.getMinJugadores();
    }
	public String getNombre() {
		return nombre;
	}
	public int getCupoMaximo() {
		return cupoMaximo;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public String getEstado() {
		return estado;
	}
	public DeporteColectivo getDeporte() {
		return deporte;
	}
	public List<Jugador> getNominaJugadores() {
		return nominaJugadores;
	}

}